from hevweb.hevweb_cli import main
main()